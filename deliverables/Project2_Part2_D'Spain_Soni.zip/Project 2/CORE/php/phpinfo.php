<?php

phpinfo()->document.getElementById('output2');

?>